import { Injectable } from '@angular/core';
import { Workout } from './workout';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WorkoutService {

  apiUrl = 'https://localhost:7205/api/Workouts';

  constructor(private http: HttpClient) { }


  //repo 
  workouts: Workout[] = [{ workoutId: 1, workoutType: "BodyBuilding", workoutName: "Climbing", caloriesBurnt: 200 },
  { workoutId: 2, workoutType: "Muscle building", workoutName: "PushUps", caloriesBurnt: 150 },
  { workoutId: 3, workoutType: "Abs", workoutName: "Crunches", caloriesBurnt: 100 },
  { workoutId: 4, workoutType: "Muscle building", workoutName: "Walking", caloriesBurnt: 200 }];

  // business logic
  getWorkouts(): Workout[] {
    return this.workouts;
  }
  //business logic
  getWorkout(workoutId: number): Workout {

    return this.workouts.find(t => t.workoutId == workoutId);
  }

  getWorkoutsFromAPI(): Observable<Workout[]> {
    return this.http.get<Workout[]>(this.apiUrl);
  }
}
