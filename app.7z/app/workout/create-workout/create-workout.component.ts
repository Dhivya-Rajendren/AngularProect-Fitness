import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Workout } from 'src/app/workout';

@Component({
  selector: 'ck-create-workout',
  templateUrl: './create-workout.component.html',
  styleUrls: ['./create-workout.component.css']
})
export class CreateWorkoutComponent implements OnInit {

  workoutForm: FormGroup;

  constructor(private _workout: Workout) { }

  ngOnInit(): void {
    this.workoutForm = new FormGroup({
      workoutId: new FormControl(),
      workoutType: new FormControl(),
      workoutName: new FormControl(),
      caloriesBurnt: new FormControl()
    });


  }
  onSubmit() {
    console.log(this.workoutForm.value);
  }

}
