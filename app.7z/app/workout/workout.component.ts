import { Component, OnInit } from '@angular/core';
import { Workout } from '../workout';

@Component({
  selector: 'ck-workout',
  templateUrl: './workout.component.html',
  styleUrls: ['./workout.component.css']
})
export class WorkoutComponent implements OnInit {

  workout: Workout = { workoutId: 1, workoutType: "BodyBuilding", workoutName: "Climbing", caloriesBurnt: 200 };

  workoutType: any = "Abs";

  constructor() { }

  ngOnInit(): void {
  }

}
