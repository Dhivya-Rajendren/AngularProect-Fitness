import { Component, OnInit, Input, SimpleChange } from '@angular/core';

import { Workout } from 'src/app/workout';
import { WorkoutService } from 'src/app/workout-service.service';

@Component({
  selector: 'ck-workoutlist',
  templateUrl: './workoutlist.component.html',
  styleUrls: ['./workoutlist.component.css']
})
export class WorkoutlistComponent implements OnInit {

  @Input() _workoutType: any;
  constructor(private workoutService: WorkoutService) { }

  _workouts: Workout[] = [];


  ngOnInit(): void {

    this.workoutService.getWorkoutsFromAPI().subscribe((result) => { console.log(result) });
  }
  ngOnChanges(changes: SimpleChange) {
    this._workouts = this.workoutService.getWorkouts().filter(t => t.workoutType == this._workoutType);
  }

}
