import { Component } from '@angular/core';
import { IDiet } from './idiet';
import { Workout } from './workout';

@Component({
  selector: 'ck-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Fitness Clinic';



}
