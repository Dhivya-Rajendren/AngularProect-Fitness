export interface IDiet {
    dietNo: number;
    dietName: string;
    dietFood: string;
    calories: number;
}
