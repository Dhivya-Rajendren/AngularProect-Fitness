import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { DietComponent } from './diet-component/diet-component.component';
import { WorkoutComponent } from './workout/workout.component';
import { DietlistComponent } from './diet-component/dietlist/dietlist.component';
import { WorkoutlistComponent } from './workout/workoutlist/workoutlist.component';
import { CreateWorkoutComponent } from './workout/create-workout/create-workout.component';
import { Workout } from './workout';
import { CreateDietComponent } from './diet-component/create-diet/create-diet.component';
import { WorkoutService } from './workout-service.service';
import { HttpClient, HttpClientModule, HttpHandler } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    DietComponent,
    WorkoutComponent,
    DietlistComponent,
    WorkoutlistComponent,
    CreateWorkoutComponent,
    CreateDietComponent
  ],
  imports: [
    BrowserModule, AppRoutingModule, FormsModule, ReactiveFormsModule, HttpClientModule
  ],
  providers: [Workout, WorkoutService, HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
