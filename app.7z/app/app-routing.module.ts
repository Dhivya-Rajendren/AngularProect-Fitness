import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { DietComponent } from './diet-component/diet-component.component';
import { WorkoutComponent } from './workout/workout.component';




const routes: Routes = [
  { path: 'Diet', component: DietComponent },
  { path: 'Workout', component: WorkoutComponent },
  { path: '', component: DietComponent, }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
