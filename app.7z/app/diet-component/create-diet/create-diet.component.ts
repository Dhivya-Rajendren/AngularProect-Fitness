import { Component, OnInit } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import { IDiet } from "src/app/idiet";
import { DietComponent } from "../diet-component.component";

@Component({
    selector: 'ck-create-diet',
    templateUrl: './create-diet.component.html'
})
export class CreateDietComponent implements OnInit {

    dietForm: FormGroup;



    ngOnInit(): void {
        this.dietForm = new FormGroup({
            dietId: new FormControl(),
            dietType: new FormControl(),
            dietName: new FormControl(),
            calories: new FormControl()

        });
    }

    onSubmit() {
        console.log(this.dietForm.value);
    }


}