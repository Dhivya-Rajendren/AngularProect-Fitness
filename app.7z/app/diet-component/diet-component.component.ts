import { Component, OnInit } from '@angular/core';
import { IDiet } from '../idiet';

@Component({
  selector: 'ck-diet-component',
  templateUrl: './diet-component.component.html',
  styleUrls: ['./diet-component.component.css']
})
export class DietComponent implements OnInit {

  dietName: any = "Veg Diet"
  diet: IDiet = { dietNo: 1, dietName: "BalancedDiet", dietFood: "Fruits & Veggies", calories: 150 };


  constructor() { }

  ngOnInit(): void {
  }

}
