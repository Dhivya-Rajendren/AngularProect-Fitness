import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { IDiet } from 'src/app/idiet';

@Component({
  selector: 'ck-dietlist',
  templateUrl: './dietlist.component.html',
  styleUrls: ['./dietlist.component.css']
})
export class DietlistComponent implements OnInit {

  constructor() { }

  @Input() inputDietName: any;
  count: any = 0;
  avalDiets: IDiet[] = [{ dietNo: 1, dietName: "BalancedDiet", dietFood: "Fruits & Veggies", calories: 150 },
  { dietNo: 2, dietName: "BodyBuildingDiet", dietFood: "Meat & eggs", calories: 250 },
  { dietNo: 3, dietName: "Veg Diet", dietFood: " Veggies & Spinach", calories: 50 },
  { dietNo: 4, dietName: "Diabetis Diet", dietFood: "Cereals & Veggies", calories: 100 }];
  diets: IDiet[] = [];
  ngOnInit(): void {
    if (this.inputDietName == null) {
      this.diets = null;
    }
    else {
      this.diets = this.avalDiets.filter(t => t.dietName == this.inputDietName);
    }
  }
  ngOnChanges(changes: SimpleChanges) {
    if (this.inputDietName == null) {
      this.diets = null;
    }

    else {
      this.diets = this.avalDiets.filter(t => t.dietName == this.inputDietName);
    }
  }

}
