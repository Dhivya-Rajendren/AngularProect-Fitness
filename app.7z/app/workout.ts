export class Workout {
    workoutId: number;
    workoutName: string;
    workoutType: string;
    caloriesBurnt: number;
}
